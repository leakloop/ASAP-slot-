#禁忌搜索求路由
import numpy as np
import matplotlib.pyplot as plt
import random as rd

import date_genreate

import time

def caculate_load2(path_load, path, load):
    for i in range(len(path)-1):
        if path[i] == 8:
            if path[i+1] ==9:
                path_load[0] = path_load[0] + load
            if path[i+1] ==10:
                path_load[1] = path_load[1] + load
            if path[i+1] == 11:
                path_load[2] = path_load[2] + load
        elif path[i] == 9:
            if path[i+1] ==8:
                path_load[3] = path_load[3] + load
            if path[i+1] ==10:
                path_load[4] = path_load[4] + load
            if path[i+1] ==11:
                path_load[5] = path_load[5] + load
        elif path[i] == 10:
            if path[i+1] ==8:
                path_load[6] = path_load[6] + load
            if path[i+1] ==9:
                path_load[7] = path_load[7] + load
            if path[i+1] ==11:
                path_load[8] = path_load[8] + load
        elif path[i] == 11:
            if path[i+1] ==8:
                path_load[9] = path_load[9] + load
            if path[i+1] ==9:
                path_load[10] = path_load[10] + load
            if path[i+1] ==10:
                path_load[11] = path_load[11] + load


def caculate_load(path_load, path, load):
    for i in range(len(path)-1):
        if path[i] == 8:
            if path[i+1] ==9:
                path_load[0] = path_load[0] + load
            if path[i+1] ==10:
                path_load[1] = path_load[1] + load
        elif path[i] == 9:
            if path[i+1] ==8:
                path_load[2] = path_load[2] + load
            if path[i+1] ==10:
                path_load[3] = path_load[3] + load
        elif path[i] == 10:
            if path[i+1] ==8:
                path_load[4] = path_load[4] + load
            if path[i+1] ==9:
                path_load[5] = path_load[5] + load




class TS():
    def __init__(self,vcount=20,ccount=20,tabul=25,iters=200,tabu_objects=10):
        self.vcount = vcount
        self.ccount = ccount
        self.iters = iters
        self.tabu_len = tabul
        self.tabu_objs = tabu_objects
        self.tabu_list = [None]*self.tabu_objs
        self.tabu_len_list = np.array([0]*self.tabu_objs)
        self.cur_solu = np.array([0] * self.vcount)
        self.best_solu = np.array([0] * self.vcount)
        self.trace = []
        self.loads = []
        self.loads_rate = []
        self.loads_std = []


    def valuate2(self, x):
        path_len = 0
        path_load = [0, 0, 0, 0, 0, 0]
        k = 0
        for i in x:
            path = date_genreate.path[k][i]
            path_len = path_len + len(path)
            caculate_load(path_load, path, self.loads[k])
            k += 1
        value = np.multiply(path_load,0.000001)
        return [np.max(value),np.std(value)]

    def valuate(self, x, path_load = []):
        path_len = 0
        if path_load == []:
            path_load = [0,0,0,0,0,0]
        k = 0
        for i in x:
            path = date_genreate.path[k][i]
            path_len = path_len + len(path)
            caculate_load(path_load, path, self.loads[k])
            k += 1
        value = np.std(path_load) + 700*path_len
        return value

    def update_Tabu(self, mode, index=None, solu=None):
        indices =[]
        for i in range(len(self.tabu_len_list)):
            if self.tabu_len_list[i] !=0:
                self.tabu_len_list[i] -= 1
        if mode == 'release':
            self.sequence_Tabu(index)
        elif mode == 'add':
            tabuObj = self.valuate(solu)
            if self.tabu_list[0] == None:
                self.sequence_Tabu(0)
            self.tabu_list[len(self.tabu_list) - 1] = tabuObj
            self.tabu_len_list[len(self.tabu_list) - 1] = self.tabu_len
        for i in range(len(self.tabu_len_list)):
            if self.tabu_len_list[i] == 0:
                indices.append(i)
        if len(indices) == 1:
            self.sequence_Tabu(indices[0])
        elif len(indices) > 1:
            maxindex = max(indices)
            self.sequence_Tabu(maxindex)
            for i in indices:
                if i !=max(indices):
                    self.tabu_list[i] = None
                    self.tabu_len_list[i] = 0
            objs =[]
            objs1 = []
            for obj in self.tabu_list[:maxindex]:
                if obj != None:
                    objs.append(obj)
            for obj in self.tabu_len_list[:maxindex]:
                if obj != 0:
                    objs1.append(obj)
            if objs != []:
                for i in range(len(objs)):
                    self.tabu_list[maxindex-i-1] = objs[i]
                    self.tabu_len_list[maxindex-i-1] = objs1[i]
                for i in range(maxindex-len(objs)):
                    self.tabu_list[i] = None
                    self.tabu_len_list[i] = 0
            else:
                for i in range(maxindex):
                    self.tabu_list[i] = None
                    self.tabu_len_list[i] = 0
    def sequence_Tabu(self, index):
        if index != len(self.tabu_list)-1:
            for i in range(len(self.tabu_list)-1-index):
                self.tabu_list[index+i] = self.tabu_list[index+i+1]
                self.tabu_len_list[index+i] = self.tabu_len_list[index+i+1]
            self.tabu_list[len(self.tabu_list)-1] = None
            self.tabu_len_list[len(self.tabu_len_list)-1] = 0

    def run(self):
        for i in range(self.vcount):
            self.loads.append(date_genreate.flow[i][3]/date_genreate.flow[i][2])

        self.cur_solu = date_genreate.short
        for i in range(self.vcount):
            # self.cur_solu[i] = rd.randint(0,date_genreate.pathlen[i]-1)
            self.best_solu[i] = self.cur_solu[i]
        self.update_Tabu('add', solu=self.cur_solu)
        counter = 0
        while counter < self.iters:
            counter += 1
            candi_solu = np.array([[0 for i in range(self.vcount)] for j in range(self.ccount)])
            for i in range(self.ccount):
                for j in range(self.vcount):
                    candi_solu[i,j] = self.cur_solu[j] + rd.randint(-1,1)
            for i in range(self.ccount):
                for j in range(self.vcount):
                    if candi_solu[i,j] > date_genreate.pathlen[j]-1:
                        candi_solu[i,j] = date_genreate.pathlen[j]-1
                    elif candi_solu[i,j] < 0:
                        candi_solu[i,j] = 0
            isALL = False
            isPart = False
            count = [0]*self.ccount
            for i in range(self.ccount):
                for k in range(len(self.tabu_list)):
                    if self.valuate(candi_solu[i]) == self.tabu_list[k]:
                        count[i] = 1
            temp = 0
            for i in count:
                if i == 1:
                    temp += 1
            if temp == self.ccount:
                isALL = True
            elif temp < self.ccount and temp > 0:
                isPart = True

            if isALL == True:
                temp_tabu_list = []
                for tabuObj in self.tabu_list:
                    if tabuObj != None:
                        temp_tabu_list.append(tabuObj)
                index = np.argmin(np.array(temp_tabu_list))
                temp_solu = np.array([0] * self.vcount)
                for solu in candi_solu:
                    if self.valuate(solu) == self.tabu_list[index]:
                        temp_solu = solu
                self.cur_solu = temp_solu
                if self.valuate(self.cur_solu) < self.valuate(self.best_solu):
                    self.best_solu = self.cur_solu
                self.update_Tabu('release', index=index)
            elif isPart == True:
                isExistbest = False
                temp_bsolu = []
                bsolu = np.array([0] * self.vcount)
                for solu in candi_solu:
                    if self.valuate(solu) < self.valuate(self.best_solu):
                        isExistbest = True
                        temp_bsolu.append(solu)
                if isExistbest == True:
                    isInTabu = False
                    index = 0
                    if len(temp_bsolu) == 1:
                        bsolu = temp_bsolu[0]
                    elif len(temp_bsolu) != 1 and len(temp_bsolu) != 0:
                        bsolu = temp_bsolu[0]
                        for solu in temp_bsolu[1:]:
                            if self.valuate(solu) < self.valuate(bsolu):
                                bsolu = solu
                    for i in range(len(self.tabu_list)):
                        if self.valuate(bsolu) == self.tabu_list[i]:
                            isInTabu = True
                            index = i
                    self.cur_solu = bsolu
                    if self.valuate(bsolu) < self.valuate(self.best_solu):
                        self.best_solu = bsolu
                    if isInTabu == True:
                        self.update_Tabu('release', index=index)
                    else:
                        index = len(self.tabu_list) - 1
                        self.update_Tabu(index, 'add', solu=self.cur_solu)
                else:
                    notInTabu = []
                    for solu in candi_solu:
                        count = 0
                        for i in range(len(self.tabu_list)):
                            if self.valuate(solu) != self.tabu_list[i]:
                                count += 1
                        if count == len(self.tabu_list):
                            notInTabu.append(solu)
                    temp_solu = notInTabu[0]
                    if len(notInTabu) != 1:
                        for solu in notInTabu[1:]:
                            if self.valuate(solu) < self.valuate(temp_solu):
                                temp_solu = solu
                    if self.valuate(temp_solu) < self.valuate(self.cur_solu):
                        self.cur_solu = temp_solu
                        self.update_Tabu('add', index=len(self.tabu_list) - 1, solu=self.cur_solu)
                        if self.valuate(self.cur_solu) < self.valuate(self.best_solu):
                            self.best_solu = self.cur_solu

            else:
                bcandi_solu = candi_solu[0]
                for solu in candi_solu[1:]:
                    if self.valuate(solu) < self.valuate(bcandi_solu):
                        bcandi_solu = solu
                if self.valuate(bcandi_solu) < self.valuate(self.cur_solu):
                    self.cur_solu = bcandi_solu
                    self.update_Tabu('add', index=len(self.tabu_list) - 1, solu=self.cur_solu)
                    if self.valuate(self.cur_solu) < self.valuate(self.best_solu):
                        self.best_solu = self.cur_solu
            self.trace.append(self.valuate(self.best_solu))
            loads_rate = self.valuate2(self.best_solu)
            self.loads_rate.append(loads_rate[0])
            self.loads_std.append(loads_rate[1])


def show_path(solu):
    k=0
    print("路径为：")
    for i in solu:
        print(date_genreate.path[k][i])
        k += 1
def main():
    start = time.time()
    ts = TS(iters=200,vcount=150)
    ts.run()
    end = time.time()
    print(end-start)
    print('最优解:', ts.best_solu)
    show_path(ts.best_solu)
    path_load = [0, 0, 0, 0, 0, 0]
    print('最小值', ts.valuate(ts.best_solu,path_load))




    plt.tight_layout()
    plt.subplot(3,1,1)
    plt.plot(ts.trace, 'r')
    title = 'TS: ' + str(ts.valuate(ts.best_solu))
    plt.title(title)
    plt.subplot(3,1,2)
    plt.tight_layout()
    load_rate = ts.valuate2(ts.best_solu)
    plt.plot(ts.loads_rate,'blue')
    plt.title('The Link Loads: ' + str(load_rate[0]))
    plt.subplot(3,1,3)
    plt.tight_layout()
    plt.plot(ts.loads_std,'black')
    plt.title('The Std of Link Loads: ' + str(load_rate[1]))
    plt.show()
if __name__ == "__main__":
    main()


