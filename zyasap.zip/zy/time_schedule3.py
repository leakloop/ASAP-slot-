#禁忌搜索求调度
import numpy as np
import random as rd
import time
import TS
import matplotlib.pyplot as plt
import date_genreate
import itertools

def road_number(before,after):
    if before == 0:
        if after == 8:
            return 0
    elif before == 1:
        if after == 8:
            return 1
    elif before == 2:
        if after == 8:
            return 2
    elif before == 3:
        if after == 9:
            return 3
    elif before == 4:
        if after == 9:
            return 4
    elif before == 5:
        if after == 9:
            return 5
    elif before == 6:
        if after == 10:
            return 6
    elif before == 7:
        if after == 10:
            return 7
    elif before == 8:
        if after == 0:
            return 8
        elif after == 1:
            return 9
        elif after == 2:
            return 10
        elif after == 9:
            return 11
        elif after == 10:
            return 12
    elif before == 9:
        if after == 3:
            return 13
        elif after == 4:
            return 14
        elif after == 5:
            return 15
        elif after == 8:
            return 16
        elif after == 10:
            return 17
    elif before == 10:
        if after == 6:
            return 18
        elif after == 7:
            return 19
        elif after == 8:
            return 20
        elif after == 9:
            return 21

def road_number2(before,after):
    if before == 0:
        if after == 8:
            return 0
    elif before == 1:
        if after == 8:
            return 1
    elif before == 2:
        if after == 9:
            return 2
    elif before == 3:
        if after == 9:
            return 3
    elif before == 4:
        if after == 10:
            return 4
    elif before == 5:
        if after == 10:
            return 5
    elif before == 6:
        if after == 11:
            return 6
    elif before == 7:
        if after == 11:
            return 7
    elif before == 8:
        if after == 0:
            return 8
        elif after == 1:
            return 9
        elif after == 9:
            return 10
        elif after == 10:
            return 11
        elif after == 11:
            return 12
    elif before == 9:
        if after == 2:
            return 13
        elif after == 3:
            return 14
        elif after == 8:
            return 15
        elif after == 10:
            return 16
        elif after == 11:
            return 17
    elif before == 10:
        if after == 4:
            return 18
        elif after == 5:
            return 19
        elif after == 8:
            return 20
        elif after == 9:
            return 21
        elif after == 11:
            return 22
    elif before == 11:
        if after == 6:
            return 23
        elif after == 7:
            return 24
        elif after == 8:
            return 25
        elif after == 9:
            return 26
        elif after ==10:
            return 27

def insert(x,a,b):
    temp = x[b]
    x[b:-1] = x[b+1:]
    x[a+1:] = x[a:-1]
    x[a] = temp
def swap(x,a,b):
    temp = x[b]
    x[b] = x[a]
    x[a] = temp

class time_schedule3():
    def __init__(self, vcount = 20, ccount = 10, tabul = 25, iters = 200, tabu_objects=10, times = [], path_len = [],length = [], rout_solu = []):
        self.vcount = vcount
        self.ccount = ccount
        self.iters = iters
        self.tabu_len = tabul
        self.tabu_objs = tabu_objects
        self.tabu_list = [None] * self.tabu_objs
        self.tabu_len_list = np.array([0] * self.tabu_objs)
        self.cur_solu = np.array([0]*self.vcount)
        self.best_solu = np.array([0]*self.vcount)
        self.trace = []
        self.times = times
        self.path_len = path_len
        self.length = length
        self.rout_solu = rout_solu
        self.road_flow = np.array([[-1 for i in range(self.vcount)]for j in range(22)])
        self.road_len = np.array([0]*22)

    def shape(self, x, flow_rank):
        for i in range(22):
            p = 0
            for j in range(self.vcount):
                for k in range(self.road_len[i]):
                    if self.road_flow[i][k] == x[j]:
                        flow_rank[i][p] = self.road_flow[i][k]
                        p += 1

    def permutation(self):
        for i in range(self.vcount):
            for j in range(self.path_len[i]):
                a = road_number(date_genreate.path[i][self.rout_solu[i]][j],
                                date_genreate.path[i][self.rout_solu[i]][j + 1])
                b = np.array(np.where(self.road_flow[a] == -1))
                self.road_flow[a][b[0][0]] = i
                self.road_len[a] = self.road_len[a] + 1

    def time_set2(self,x,time_table,i):
        time_head = []
        for j in range(self.path_len[i]):
            r = road_number(date_genreate.path[i][self.rout_solu[i]][j],date_genreate.path[i][self.rout_solu[i]][j+1])
            a = np.array(np.where(x[r] == i))
            if a != 0:
                temp_i = int(x[r][a - 1])
                temp_n = int(np.array(np.where(
                    np.array(date_genreate.path[temp_i][self.rout_solu[temp_i]]) == date_genreate.path[i][self.rout_solu[i]][
                        j])))
                time_head.append(time_table[temp_i][temp_n] + self.length[temp_i] - j*self.length[i])
            else:
                time_head.append(0-j*self.length[i])
        time_table[i][0] = max(time_head)
        for j in range(self.path_len[i]):
            if j != 0:
                time_table[i][j] = time_table[i][j-1] + self.length[i]

    def valuate2(self,x):
        flow_rank = np.array([[-1 for i in range(self.vcount)] for j in range(22)])
        time_table = np.array([[-1 for i in range(4)] for j in range(self.vcount)])
        self.shape(x, flow_rank)
        for i in range(self.vcount):
            self.time_set2(flow_rank,time_table,x[i])
        return np.max(time_table)



    def valuate(self,x):
        flow_rank = np.array([[-1 for i in range(self.vcount)]for j in range(22)])
        time_table = np.array([[-1 for i in range(4)] for j in range(self.vcount)])
        self.shape(x,flow_rank)
        for i in range(self.vcount):
            for j in range(self.path_len[i]):
                self.time_set(flow_rank, time_table, i, j)
        f2 = 0
        for i in range(self.vcount):
            f2 = f2 + time_table[i][self.path_len[i]-1] - time_table[i][0]
        return 10*np.max(time_table)+f2

    def time_set(self, x, time_table, i ,j):
        if time_table[i][j] != -1:
            return
        r = road_number(date_genreate.path[i][self.rout_solu[i]][j], date_genreate.path[i][self.rout_solu[i]][j + 1])
        a = np.array(np.where(x[r] == i))
        if a != 0:
            temp_i = int(x[r][a - 1])
            temp_n = int(np.array(np.where(
                np.array(date_genreate.path[temp_i][self.rout_solu[temp_i]]) == date_genreate.path[i][self.rout_solu[i]][j])))
            if time_table[temp_i][temp_n] != -1:  # 前有值
                if j != 0:
                    if time_table[i][j - 1] != -1:
                        time_table[i][j] = max(
                            [time_table[temp_i][temp_n] + self.length[temp_i], time_table[i][j - 1] + self.length[i]])
                    if time_table[i][j - 1] == -1:
                        self.time_set(x, time_table, i, j - 1)
                        time_table[i][j] = max([time_table[temp_i][temp_n] + self.length[temp_i],time_table[i][j - 1] + self.length[i]])
                else:
                    time_table[i][j] = time_table[temp_i][temp_n] + self.length[temp_i]
            else:
                self.time_set(x, time_table, temp_i, temp_n)
                if j != 0:
                    if j != 0:
                        if time_table[i][j - 1] != -1:
                            time_table[i][j] = max([time_table[temp_i][temp_n] + self.length[temp_i],
                                                    time_table[i][j - 1] + self.length[i]])
                    if time_table[i][j - 1] == -1:
                        self.time_set(x, time_table, i, j - 1)
                        time_table[i][j] = max(
                            [time_table[temp_i][temp_n] + self.length[temp_i], time_table[i][j - 1] + self.length[i]])
                else:
                    time_table[i][j] = time_table[temp_i][temp_n] + self.length[temp_i]
        else:
            if j == 0:
                r3 = road_number(date_genreate.path[i][self.rout_solu[i]][j + 1],
                                 date_genreate.path[i][self.rout_solu[i]][j + 2])
                a3 = np.array(np.where(x[r3] == i))
                if a3 == 0:
                    time_table[i][j] = 0
                if a3 != 0:
                    temp_iii = int(x[r3][a3 - 1])
                    temp_nnn = int(np.array(np.where(
                        np.array(date_genreate.path[temp_iii][self.rout_solu[temp_iii]]) == date_genreate.path[i][self.rout_solu[i]][
                            j + 1])))
                    if time_table[temp_iii][temp_nnn] != -1:
                        time_table[i][j] = max(time_table[temp_iii][temp_nnn] - self.length[i] + 1, 0)
                    if time_table[temp_iii][temp_nnn] == -1:
                        self.time_set(x, time_table, temp_iii, temp_nnn)
                        time_table[i][j] = max(time_table[temp_iii][temp_nnn] - self.length[i] + 1, 0)
            else:
                if time_table[i][j - 1] != -1:
                    time_table[i][j] = time_table[i][j - 1] + self.length[i]
                if time_table[i][j - 1] == -1:
                    self.time_set(x, time_table, i, j - 1)
                    time_table[i][j] = time_table[i][j - 1] + self.length[i]

    def update_Tabu(self,mode, index=None, solu=None):
        indices = []
        for i in range(len(self.tabu_len_list)):
            if self.tabu_len_list[i] != 0:
                self.tabu_len_list[i] -= 1
        if mode == 'release':
            self.sequence_Tabu(index)
        elif mode == 'add':
            tabuObj = self.valuate2(solu)
            # tabuObj = self.valuate(solu)
            if self.tabu_list[0] == None:
                self.sequence_Tabu(0)
            self.tabu_list[len(self.tabu_list) - 1] = tabuObj
            self.tabu_len_list[len(self.tabu_list) - 1] = self.tabu_len
        for i in range(len(self.tabu_len_list)):
            if self.tabu_len_list[i] == 0:
                indices.append(i)
        if len(indices) == 1:
            self.sequence_Tabu(indices[0])
        elif len(indices) > 1:
            maxindex = max(indices)
            self.sequence_Tabu(maxindex)
            for i in indices:
                if i != max(indices):
                    self.tabu_list[i] = None
                    self.tabu_len_list[i] = 0
            objs = []
            objs1 = []
            for obj in self.tabu_list[:maxindex]:
                if obj != None:
                    objs.append(obj)
            for obj in self.tabu_len_list[:maxindex]:
                if obj != 0:
                    objs1.append(obj)
            if objs != []:
                for i in range(len(objs)):
                    self.tabu_list[maxindex - i - 1] = objs[i]
                    self.tabu_len_list[maxindex - i - 1] = objs1[i]
                for i in range(maxindex - len(objs)):
                    self.tabu_list[i] = None
                    self.tabu_len_list[i] = 0
            else:
                for i in range(maxindex):
                    self.tabu_list[i] = None
                    self.tabu_len_list[i] = 0

    def sequence_Tabu(self, index):
        if index != len(self.tabu_list) - 1:
            for i in range(len(self.tabu_list) - 1 - index):
                self.tabu_list[index + i] = self.tabu_list[index + i + 1]
                self.tabu_len_list[index + i] = self.tabu_len_list[index + i + 1]
            self.tabu_list[len(self.tabu_list) - 1] = None
            self.tabu_len_list[len(self.tabu_len_list) - 1] = 0

    def run(self):
        flow = []
        step1 = 1
        if step1 < 1 :
            step1 = 1
        step2 = 1
        if step2 < 1 :
            step2 = 1
        step3 = 1
        if step3 < 1 :
            step3 = 1
        step4 = 1

        length = sorted(enumerate(np.multiply(self.length,self.path_len)), key=lambda x: x[1])
        idl = [i[0] for i in length]
        for i in range(3):
            for j in range(int(self.vcount/3)+1):
                if j * 3 + i > self.vcount - 1:
                    continue
                flow.append(idl[j * 3 + i])
        rd.shuffle(flow)
        # i1 = 0
        # i2 = 0
        # for i in range(self.vcount):
        #     if i%2 == 0:
        #         flow.append(idl[i1])
        #         i1 += 1
        #     else:
        #         flow.append(idl[self.vcount-1-i2])
        #         i2 += 1
        # best_flow = []
        # best_value = 0
        # for k in range(100):
        #     if k == 0:
        #         for i in range(self.vcount):
        #             flow.append(i)
        #         rd.shuffle(flow)
        #         best_flow = flow
        #         best_value = self.valuate2(flow)
        #
        #
        #     else:
        #         rd.shuffle(flow)
        #         if self.valuate2(flow)<best_value:
        #             best_flow = flow
        #             best_value = self.valuate2(flow)

        self.cur_solu = flow
        self.best_solu = flow
        self.update_Tabu('add', solu=self.cur_solu)


        last_b = np.array([0]*self.vcount)
        counter = 0
        while counter < self.iters:
            att=0
            if len(self.trace)>0:
                if self.valuate2(self.best_solu) != self.trace[-1]:
                    error = 1
            counter += 1
            candi_solu = np.array([[0 for i in range(self.vcount)]for j in range(self.ccount)])
            step = 1
            if counter < 40:
                step=step1
            else:
                step = step4
            for i in range(self.ccount):
                temp1 = self.cur_solu
                if step == 1:
                    a = rd.randint(0, self.vcount - 1)
                    b = rd.randint(0, self.vcount - 1)
                    if i < 5:
                        candi_solu[i][b] = temp1[a]
                        k = 0
                        for j in range(self.vcount):
                            if j != b:
                                if k == a:
                                    k += 1
                                candi_solu[i][j] = temp1[k]
                                k += 1

                    else:
                        candi_solu[i] = temp1
                        candi_solu[i][a] = temp1[b]
                        candi_solu[i][b] = temp1[a]
                else:
                    if step == step1:
                        a = rd.randint(0, int(self.vcount/4)-1)
                        b = rd.randint(0, int(self.vcount/4)-1)
                        if i < 5:
                            for j in range(step1):
                                insert(temp1,a*step1+j,b*step1+j)
                            candi_solu[i] = temp1
                        else:
                            for j in range(step1):
                                swap(temp1,a*step1+j,b*step1+j)
                            candi_solu[i] = temp1
                    elif step == step2:
                        a = rd.randint(0, int(self.vcount/3)-1)
                        b = rd.randint(0, int(self.vcount/3)-1)
                        if i < 5:
                            for j in range(step2):
                                insert(temp1,a*step2+j,b*step2+j)
                            candi_solu[i] = temp1
                        else:
                            for j in range(step2):
                                swap(temp1,a*step2+j,b*step2+j)
                            candi_solu[i] = temp1
                    elif step == step3:
                        a = rd.randint(0, int(self.vcount/2)-1)
                        b = rd.randint(0, int(self.vcount/2)-1)
                        if i < 5:
                            for j in range(step3):
                                insert(temp1,a*step3+j,b*step3+j)
                            candi_solu[i] = temp1
                        else:
                            for j in range(step3):
                                swap(temp1,a*step3+j,b*step3+j)
                            candi_solu[i] = temp1




            # for i in range(self.ccount):
            #     if i == 0:
            #         temp1 = np.array(self.cur_solu[i])
            #     else:
            #         temp1 = np.array(self.cur_solu[:2*i+1])
            #         rd.shuffle(temp1)
            #     temp2 = self.cur_solu[2*i+1:]
            #     temp3 = np.append(temp1,temp2)
            #     candi_solu[i] = temp3



            # for i in range(self.ccount):
            #     candi_solu[i] = self.cur_solu
            #     for j in range(self.vcount):
            #         step = rd.randint(-1,1)
            #         if j >0 and j < 19:
            #             temp = candi_solu[i][j]
            #             candi_solu[i][j] = candi_solu[i][j + step]
            #             candi_solu[i][j+step] = temp
            #         elif j == 0:
            #             if step < 0:
            #                 step = 0
            #             temp = candi_solu[i][j]
            #             candi_solu[i][j] = candi_solu[i][j + step]
            #             candi_solu[i][j + step] = temp
            #         elif j == 19:
            #             if step > 0:
            #                 step = 0
            #             temp = candi_solu[i][j]
            #             candi_solu[i][j] = candi_solu[i][j + step]
            #             candi_solu[i][j + step] = temp
            isALL = False
            isPart = False
            count = [0] * self.ccount
            for i in range(self.ccount):
                v_can = self.valuate2(candi_solu[i])
                for k in range(len(self.tabu_list)):
                    if v_can == self.tabu_list[k]:
                    # if self.valuate(candi_solu[i]) == self.tabu_list[k]:
                        count[i] = 1
            temp = 0
            for i in count:
                if i == 1:
                    temp += 1
            if temp == self.ccount:
                isALL = True
            elif temp < self.ccount and temp > 0:
                isPart = True

            if isALL == True:
                att += 1
                temp_tabu_list = []
                for tabuObj in self.tabu_list:
                    if tabuObj != None:
                        temp_tabu_list.append(tabuObj)
                index = np.argmin(np.array(temp_tabu_list))
                temp_solu = np.array([0] * self.vcount)
                for solu in candi_solu:
                    if self.valuate2(solu) == self.tabu_list[index]:
                        temp_solu = solu
                self.cur_solu = temp_solu
                if self.valuate2(self.cur_solu) < self.valuate2(self.best_solu):
                    self.best_solu = self.cur_solu

                self.update_Tabu('release', index=index)
            elif isPart == True:
                att += 1
                isExistbest = False
                temp_bsolu = []
                bsolu = np.array([0] * self.vcount)
                for solu in candi_solu:
                    if self.valuate2(solu) < self.valuate2(self.best_solu):
                        isExistbest = True
                        temp_bsolu.append(solu)
                if isExistbest == True:
                    isInTabu = False
                    index = 0
                    if len(temp_bsolu) == 1:
                        bsolu = temp_bsolu[0]
                        v_can = self.valuate2(bsolu)
                    elif len(temp_bsolu) != 1 and len(temp_bsolu) != 0:
                        bsolu = temp_bsolu[0]
                        v_can = self.valuate2(bsolu)
                        for solu in temp_bsolu[1:]:
                            if self.valuate2(solu) < v_can:
                                bsolu = solu
                                v_can = self.valuate2(bsolu)
                    for i in range(len(self.tabu_list)):
                        if self.valuate2(bsolu) == self.tabu_list[i]:
                            isInTabu = True
                            index = i
                    self.cur_solu = bsolu
                    if self.valuate2(bsolu) < self.valuate2(self.best_solu):
                        self.best_solu = bsolu

                    if isInTabu == True:
                        self.update_Tabu('release', index=index)
                    else:
                        index = len(self.tabu_list) - 1
                        self.update_Tabu(index, 'add', solu=self.cur_solu)
                else:
                    notInTabu = []
                    for solu in candi_solu:
                        v_can = self.valuate2(solu)
                        count = 0
                        for i in range(len(self.tabu_list)):
                            if v_can != self.tabu_list[i]:
                                count += 1
                        if count == len(self.tabu_list):
                            notInTabu.append(solu)
                    temp_solu = notInTabu[0]
                    if len(notInTabu) != 1:
                        for solu in notInTabu[1:]:
                            if self.valuate2(solu) < self.valuate2(temp_solu):
                                temp_solu = solu
                    if self.valuate2(temp_solu) < self.valuate2(self.cur_solu):
                        self.cur_solu = temp_solu
                        self.update_Tabu('add', index=len(self.tabu_list) - 1, solu=self.cur_solu)
                        if self.valuate2(self.cur_solu) < self.valuate2(self.best_solu):
                            self.best_solu = self.cur_solu
                            att+=1
            else:
                bcandi_solu = candi_solu[0]
                v_bcandi = self.valuate2(bcandi_solu)
                for solu in candi_solu[1:]:
                    if self.valuate2(solu) < v_bcandi:
                        bcandi_solu = solu
                        v_bcandi = self.valuate2(bcandi_solu)
                if self.valuate2(bcandi_solu) < self.valuate2(self.cur_solu):
                    self.cur_solu = bcandi_solu
                    self.update_Tabu('add', index=len(self.tabu_list) - 1, solu=self.cur_solu)
                    if len(self.trace) > 0:
                        if self.valuate2(self.best_solu) != self.trace[-1]:
                            if (np.array(self.best_solu)== last_b).all():
                                error = 1
                            error = 2
                    if self.valuate2(self.cur_solu) < self.valuate2(self.best_solu):
                        self.best_solu = self.cur_solu
            last_b = np.array(self.best_solu)
            self.trace.append(self.valuate2(self.best_solu))

def main():
    start1 = time.time()
    times = []
    length = []
    path_len = []
    ts = TS.TS(iters=300,vcount=40)
    ts.run()
    path_load = [0, 0, 0, 0, 0, 0]
    ts.valuate(ts.best_solu, path_load)
    m = np.array(path_load)
    np.save("path_load.npy", m)
    m2 = np.array(ts.best_solu)
    np.save("rout.npy", m2)
    for i in range(ts.vcount):
        times.append(date_genreate.flow[i][2])
        length.append(int(date_genreate.flow[i][3]/1000) + 6)
        path_len.append(len(date_genreate.path[i][ts.best_solu[i]]) - 1)
    time_s = time_schedule3(iters=400,times=times,length=length,path_len=path_len,rout_solu=ts.best_solu,vcount=40,tabul=10,tabu_objects=25,ccount=15)
    time_s.permutation()
    time_s.run()
    end1 = time.time()
    print(end1 - start1)
    print('最优解:', time_s.best_solu)
    print('最小值', time_s.valuate2(time_s.best_solu))

    plt.subplot(2,1,1)
    plt.plot(time_s.trace, 'r')
    TS.show_path(ts.best_solu)
    title = 'TS: ' + str(time_s.valuate2(time_s.best_solu))
    plt.title(title)
    rank = []
    for i in range(time_s.vcount):
        rank.append(time_s.length[time_s.best_solu[i]]*time_s.length[i]*(time_s.path_len[i]))
    rank = np.array(rank)
    plt.subplot(2,1,2)
    plt.plot(rank)
    #     plt.scatter(i,time_s.length[time_s.best_solu[i]],c='blue')
    plt.show()
    m = np.array(time_s.best_solu)
    np.save("demo.npy",m)

if __name__ == "__main__":

    main()