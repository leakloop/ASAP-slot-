#用来完成新增动态流量调度，flowapn_rate()用于计算链路负载
import numpy as np
from time_schedule3 import road_number
import date_genreate
from dynamic_schedule import re_time
from dynamic_schedule import find_slot
from TS import caculate_load
from TS import caculate_load2
import time
import matplotlib.pyplot as plt

def flowapn_rate(time_table):
    r1 = road_number(8, 9)
    temp = 0
    load_rate = []
    for i in range(len(time_table[r1])):
        if time_table[r1][i][1]>1000:
            break
        temp += time_table[r1][i][1]-time_table[r1][i][0]
    load_rate.append(1-temp/time_table[r1][i][0])
    r2 = road_number(8, 10)
    temp = 0
    for i in range(len(time_table[r2])):
        if time_table[r2][i][1] > 1000:
            break
        temp += time_table[r2][i][1] - time_table[r2][i][0]
    load_rate.append(1 - temp / time_table[r2][i][0])
    r3 = road_number(9, 8)
    temp = 0
    for i in range(len(time_table[r3])):
        if time_table[r3][i][1] > 1000:
            break
        temp += time_table[r3][i][1] - time_table[r3][i][0]
    load_rate.append(1 - temp / time_table[r3][i][0])
    r4 = road_number(9, 10)
    temp = 0
    for i in range(len(time_table[r4])):
        if time_table[r4][i][1] > 1000:
            break
        temp += time_table[r4][i][1] - time_table[r4][i][0]
    load_rate.append(1 - temp / time_table[r4][i][0])
    r5 = road_number(10, 8)
    temp = 0
    for i in range(len(time_table[r5])):
        if time_table[r5][i][1] > 1000:
            break
        temp += time_table[r5][i][1] - time_table[r5][i][0]
    load_rate.append(1 - temp / time_table[r5][i][0])
    r6 = road_number(10, 9)
    temp = 0
    for i in range(len(time_table[r6])):
        if time_table[r6][i][1] > 1000:
            break
        temp += time_table[r6][i][1] - time_table[r6][i][0]
    load_rate.append(1 - temp / time_table[r6][i][0])
    print(load_rate)


flow_number = 300
time_table = [[]for i in range(22)]
for i in range(22):
    time_table[i].append([0,4000])
path_loads = [0, 0, 0, 0, 0, 0,0,0,0,0,0,0]
schedule_result = []
max_loads = []
average_loads = []
flow = date_genreate.flow_generate(flow_number)
# flow = date_genreate.flow
f_id = []
path_loads2 = [0, 0, 0, 0, 0, 0,0,0,0,0,0,0]
max_loads2 = []
average_loads2 = []
pathsss = []
for i in range(flow_number):
    f_id.append(flow[i])
    f_id[i][3] = -f_id[i][3]
f_id.sort(key=lambda x: (x[2],x[3]))
for i in range(flow_number):
    src = f_id[i][0]-1
    dst = f_id[i][1]-1
    times = f_id[i][2]
    length = -f_id[i][3]
    p = date_genreate.find_path(src, dst, date_genreate.paths2)
    best_path = p[0]
    temp = np.array(path_loads)
    caculate_load2(temp, p[0], length / times)
    v = np.std(temp) + 800 * len(p[0])
    v2 = len(p[0])
    best_path2 = p[0]
    for j in range(len(p)):

        temp_p2 = np.array(path_loads2)
        caculate_load2(temp_p2,p[j],length/times)
        temp_v2 = len(p[j])
        if temp_v2 < v2 :
            best_path2 = p[j]
            v2 = temp_v2

        temp_p = np.array(path_loads)
        caculate_load2(temp_p,p[j],length/times)
        temp_v = np.std(temp_p) + 800*len(p[j])
        if temp_v < v:
            best_path = p[j]
            v = temp_v
    caculate_load2(path_loads2, best_path2, length / times)
    average_loads2.append(np.mean(path_loads2) / 10000)
    max_loads2.append(max(path_loads2) / 10000)
    caculate_load2(path_loads, best_path, length / times)
    length = int(length/1000) + 6
    path_len = len(best_path)
    average_loads.append(np.mean(path_loads)/10000)
    max_loads.append(max(path_loads)/10000)
    # schedule_result.append(find_slot(time_table, length, path_len - 1, times,best_path,2))
    pathsss.append(best_path)
#flowapn_rate(time_table)
m=np.array(schedule_result)
np.save("10flows.npy",m)
plt.tight_layout()
plt.subplot(2,1,1)
title = "mean of path_loads"
plt.title(title)
plt.plot(average_loads)
plt.plot(average_loads2)
plt.legend(["load balancing algorithrm","minimum path algorithm"])
plt.tight_layout()

plt.subplot(2,1,2)
plt.tight_layout()
title="max of path_loads"
plt.title(title)
plt.plot(max_loads)
plt.plot(max_loads2)
plt.legend(["load balancing algorithrm","minimum algorithrm"])

plt.show()
src = 7
dst = 5
times = 2
length = 7552
pad = date_genreate.find_path(src, dst, date_genreate.paths)
best_path = pad[0]
temp = np.array(path_loads)
caculate_load(temp, pad[0], length / times)
v =  1000 * len(pad[0])
for j in range(len(pad)):
    temp_p = np.array(path_loads)
    caculate_load(temp_p,pad[j],length/times)
    temp_v =  1000*len(pad[j])
    if temp_v < v:
        best_path = pad[j]
        v = temp_v
path_len = len(best_path)
length = int(length/1000) + 6
schedule = find_slot(time_table, length, path_len - 1, times,best_path)
print(schedule)


