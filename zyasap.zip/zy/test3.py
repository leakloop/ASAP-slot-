import test2
import test1
import numpy as np
import time

def caculate_load(path_load, path, load):
    for i in range(len(path)-1):
        road_number = test1.edges.index((path[i],path[i+1]))
        path_load[road_number] += load

time_table = [[]for i in range(len(test1.edges))]
for i in range(len(test1.edges)):
    time_table[i].append([0,4000])
path_load = [0]*(len(test1.edges))
flow = []
flow_number = test1.flow_number
time_start = time.time()
for i in range(flow_number):
    flow.append(test1.flow[i])
    flow[i][3] = -flow[i][3]
flow.sort(key=lambda x: (x[2],x[3]))
schedule = [[] for i in range(flow_number)]
for i in range(flow_number):
    src = flow[i][0]-1
    dst = flow[i][1]-1
    times = flow[i][2]
    length = -flow[i][3]
    p = test1.find_path(src,dst)
    best_path = p[0]
    temp = np.array(path_load)
    v = np.std(temp) + 500 * len(p[0])
    for j in range(len(p)):
        temp_p = np.array(path_load)
        caculate_load(temp_p, p[j], length / times)
        temp_v = np.std(temp_p) + 500 * len(p[j])
        if temp_v < v:
            best_path = p[j]
            v = temp_v
    length_take = int(length/1000) + 6
    caculate_load(path_load, p[j], length / times)
    schedule[i] = test2.find_slot(time_table,length_take,len(best_path),times,best_path)
time_end = time.time()
t = time_end-time_start
print("time:"+ str(t))
success = 0
s = np.array(schedule)
for i in range(flow_number):
    if schedule[i] != -1:
        success +=1
print("success_rate" + str(success/flow_number))