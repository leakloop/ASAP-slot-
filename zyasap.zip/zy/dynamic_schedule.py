#用于故障链路动态流量进行调度，初始调度这里通过禁忌搜索完成。
#其中函数find_slot()用于寻找可用时隙，re_time()用于归还时间资源

import numpy as np
import TS
import date_genreate
import conflict
from conflict import div_slot
from time_schedule3 import road_number,road_number2
import time

flow_number = 10
timet = np.load("demo.npy")
path_loads = np.load("path_load.npy")
time_table = [[]for i in range(22)]
times = []
length = []
path_len = []
rout = np.load("rout.npy")
for i in range(len(rout)):
    times.append(date_genreate.flow[i][2])
    length.append(int(date_genreate.flow[i][3] / 1000) + 6)
    path_len.append(len(date_genreate.path[i][rout[i]]) - 1)
time_s = conflict.time_schedule3(iters=400, times=times, length=length, path_len=path_len, rout_solu=rout, vcount=flow_number,
                        tabul=10, tabu_objects=25, ccount=15)
ts = TS.TS(iters=300,vcount=flow_number)
for i in range(22):
    time_table[i].append([0,4000])
flow_time = time_s.valuate2(timet,time_table)



def find_slot(time_table,length , path_len , times, best_path, version = 1):
    slot = [[[]for i in range(int(4/times))]for j in range(path_len)]
    for h in range(path_len):
        if version == 1:
            road = road_number(best_path[h],
                            best_path[h + 1])
        else:
            road = road_number2(best_path[h],
                               best_path[h + 1])
        temp=time_table[road]
        for i in range(int(4 / times)):
            for j in range(len(time_table[road])):
                if (temp[j][0] - 1000*(i+1)*times)*(temp[j][1] - 1000*i*(times)) <= 0:
                    if temp[j][1] - temp[j][0] >= length:
                        slot[h][i].append([max(temp[j][0] - h * length, 1000 * i * times - h * length)-1000*i*times, min(
                               [temp[j][1] - (h+1) * length,
                               (i + 1) * times * 1000 - (h+1) * length])-1000*i*times])
    slot1 = [[]for i in range(path_len)]
    for i in range(path_len):
        j = 0
        f = 0
        while j != len(slot[i][0]):
            if f == 0:
                temp_t = np.array(slot[i][0][j])
            conflict = 0
            f = 0
            for k in range(int(4/times)-1):
                s = 0
                for h in range(len(slot[i][k+1])):
                    if (slot[i][k+1][h][0] - temp_t [1])*(slot[i][k+1][h][1] - temp_t[0]) <= 0:
                        s = 1
                        if slot[i][k+1][h][0] > temp_t[0]:
                            temp_t[0] = slot[i][k + 1][h][0]
                        if slot[i][k+1][h][1] < temp_t[1]:
                            temp_tt = np.array([slot[i][k+1][h][1]+1,temp_t[1]])
                            f = 1
                            temp_t[1] =  slot[i][k+1][h][1]

                if s == 0:
                    break
                conflict += s
            if conflict == int(4/times)-1:
                slot1[i].append(temp_t)
                if f == 1:
                    temp_t=temp_tt
                    j -= 1
            j += 1
    slot2 = []

    f1 = 0
    i=0
    while i != len(slot1[0]):
        if path_len == 3:
            temp_tt = np.array(slot1[0][i])
            f1 = 0
            j = 0
            while j != len(slot1[1]):
                conflict = 0
                if (slot1[1][j][1] - temp_tt[0])*(slot1[1][j][0] - temp_tt[1]) <= 0:
                    if slot1[1][j][0] > temp_tt[0]:
                        temp_tt[0] = slot1[1][j][0]
                    if slot1[1][j][1] < temp_tt[1]:
                        t_tt = [slot1[1][j][1] + 1, temp_tt[1]]
                        f1 = 1
                        temp_tt[1] = slot1[1][j][1]
                    conflict += 1
                    f2 = 0
                    k = 0
                    while k != len(slot1[2]):
                        f2 = 0
                        if (slot1[2][k][1] - temp_tt[0]) * (slot1[2][k][0] - temp_tt[1]) <= 0:
                            if slot1[2][k][0] > temp_tt[0]:
                                temp_tt[0] = slot1[2][k][0]
                            if slot1[2][k][1] < temp_tt[1]:
                                f2 = 1
                                t_ttt = [slot1[2][k][1]+1 , temp_tt[1]]
                                temp_tt[1] = slot1[2][k][1]
                            conflict += 1
                        if conflict == path_len-1:
                            break
                        k+=1
                        if f2 == 1:
                            temp_tt = t_ttt
                    if conflict == path_len-1:
                        slot2.append(temp_tt)
                        break
                j+=1
                if f1 == 1:
                    temp_tt = t_tt

        elif path_len == 2:
            temp_tt = np.array(slot1[0][i])
            f1 = 0

            for j in range(len(slot1[1])):
                conflict = 0
                if (slot1[1][j][1] - temp_tt[0])*(slot1[1][j][0] - temp_tt[1]) <= 0:
                    if slot1[1][j][0] > temp_tt[0]:
                        temp_tt[0] = slot1[1][j][0]
                    if slot1[1][j][1] < temp_tt[1]:
                        f1 = 1
                        t_tt = [slot1[1][j][1]+1 , temp_tt[1]]
                        temp_tt[1] = slot1[1][j][1]
                    conflict += 1
                    if conflict == path_len-1:
                        slot2.append(temp_tt)
                        break
                if f1 == 1:
                    temp_tt=t_tt

        elif path_len == 4:
            temp_tt = np.array(slot1[0][i])
            f1 = 0
            j = 0
            while j != len(slot1[1]):
                conflict = 0
                temp_ttt = np.array(slot1[1][j])
                if (temp_ttt[1] - temp_tt[0])*(temp_ttt[0] - temp_tt[1]) <= 0:
                    if temp_ttt[0] > temp_tt[0]:
                        temp_tt[0] = temp_ttt[0]
                    if temp_ttt[1] < temp_tt[1]:
                        t_tt = [temp_ttt[1]+1,temp_tt[1]]
                        f1 = 1
                        temp_tt[1] = temp_ttt[1]

                    conflict += 1
                    k = 0
                    f2 = 0
                    while k != len(slot1[2]):
                        temp_tttt = slot1[2][k]
                        f2 = 0
                        if (temp_tttt[1] - temp_tt[0]) * (temp_tttt[0] - temp_tt[1]) <= 0:
                            if temp_tttt[0] > temp_tt[0]:
                                temp_tt[0] = temp_tttt[0]
                            if temp_tttt[1] < temp_tt[1]:
                                f2 = 1
                                t_ttt = [temp_tttt[1]+1,temp_tt[1]]
                                temp_tt[1] = temp_tttt[1]
                            conflict += 1
                            h = 0
                            f3 = 0
                            while h != len(slot1[3]):
                                f3 = 0
                                if (slot1[3][h][1] - temp_tt[0]) * (slot1[3][h][0] - temp_tt[1]) <= 0:
                                    if slot1[3][h][0] > temp_tt[0]:
                                        temp_tt[0] = slot1[3][h][0]
                                    if slot1[3][h][1] < temp_tt[1]:
                                        f3 = 1
                                        t_tttt = [slot1[3][h][1]+1,temp_tt[1]]
                                        temp_tt[1] = slot1[3][h][1]
                                    conflict += 1
                                if conflict == path_len - 1:
                                    break
                                if f3 == 1:
                                    temp_tt = t_tttt
                                h += 1
                        if conflict == path_len-1:
                            break
                        k += 1
                        if f2 == 1:
                            temp_tt = t_ttt
                    if conflict == path_len-1:
                        slot2.append(temp_tt)
                        break
                j += 1
                if f1 == 1:
                    temp_tt = t_tt
        elif path_len == 5:
            temp_tt = np.array(slot1[0][i])
            f1 = 0
            j = 0
            while j != len(slot1[1]):
                conflict = 0
                temp_ttt = np.array(slot1[1][j])
                if (temp_ttt[1] - temp_tt[0])*(temp_ttt[0] - temp_tt[1]) <= 0:
                    if temp_ttt[0] > temp_tt[0]:
                        temp_tt[0] = temp_ttt[0]
                    if temp_ttt[1] < temp_tt[1]:
                        t_tt = [temp_ttt[1]+1,temp_tt[1]]
                        f1 = 1
                        temp_tt[1] = temp_ttt[1]

                    conflict += 1
                    k = 0
                    f2 = 0
                    while k != len(slot1[2]):
                        temp_tttt = slot1[2][k]
                        f2 = 0
                        if (temp_tttt[1] - temp_tt[0]) * (temp_tttt[0] - temp_tt[1]) <= 0:
                            if temp_tttt[0] > temp_tt[0]:
                                temp_tt[0] = temp_tttt[0]
                            if temp_tttt[1] < temp_tt[1]:
                                f2 = 1
                                t_ttt = [temp_tttt[1]+1,temp_tt[1]]
                                temp_tt[1] = temp_tttt[1]
                            conflict += 1
                            h = 0
                            f3 = 0
                            while h != len(slot1[3]):
                                f3 = 0
                                if (slot1[3][h][1] - temp_tt[0]) * (slot1[3][h][0] - temp_tt[1]) <= 0:
                                    if slot1[3][h][0] > temp_tt[0]:
                                        temp_tt[0] = slot1[3][h][0]
                                    if slot1[3][h][1] < temp_tt[1]:
                                        f3 = 1
                                        t_tttt = [slot1[3][h][1]+1,temp_tt[1]]
                                        temp_tt[1] = slot1[3][h][1]
                                    conflict += 1
                                    g = 0
                                    f4 = 0
                                    while g != len(slot1[4]):
                                        f4 = 0
                                        if (slot1[4][g][1] - temp_tt[0]) * (slot1[4][g][0] - temp_tt[1]) <= 0:
                                            if slot1[4][g][0] > temp_tt[0]:
                                                temp_tt[0] = slot1[4][g][0]
                                            if slot1[4][g][1] < temp_tt[1]:
                                                f3 = 1
                                                t_ttttt = [slot1[4][g][1] + 1, temp_tt[1]]
                                                temp_tt[1] = slot1[4][g][1]
                                            conflict += 1
                                        if conflict == path_len -1:
                                            break
                                        if f4 == 1:
                                            temp_tt = t_ttttt
                                        g += 1
                                if conflict == path_len - 1:
                                    break
                                if f3 == 1:
                                    temp_tt = t_tttt
                                h += 1
                        if conflict == path_len-1:
                            break
                        k += 1
                        if f2 == 1:
                            temp_tt = t_ttt
                    if conflict == path_len-1:
                        slot2.append(temp_tt)
                        break
                j += 1
                if f1 == 1:
                    temp_tt = t_tt

        i += 1

    for i in range(path_len):
        if version == 1:
            road = road_number(best_path[i],
                            best_path[i + 1])
        else:
            road = road_number2(best_path[i],
                               best_path[i + 1])
        for j in range(int(4 / times)):
            x1 = slot2[0][0] + j * times * 1000 + i * length
            x2 = slot2[0][0] + length + j * times * 1000 + i * length
            for k in range(len(time_table[road])):
                if time_table[road][k][0] <= x1 and time_table[road][k][1] >= x2:
                    time1 = div_slot(time_table[road][k], x1, x2)
                    break
            del time_table[road][k]
            for l in range(len(time1)):
                time_table[road].insert(k + l, time1[l])
    return slot2[0][0]

def re_time(id,time_table,version=1):
    for i in range(len(date_genreate.path[id][rout[id]]) -1 ):
        if version == 1:
            r = road_number(date_genreate.path[id][rout[id]][i],date_genreate.path[id][rout[id]][i+1])
        else:
            r = road_number2(date_genreate.path[id][rout[id]][i], date_genreate.path[id][rout[id]][i + 1])
        for j in range(int(4/date_genreate.flow[id][2])):
            for k in range(len(time_table[r])):
                if time_table[r][k][0] >= flow_time[id] +j*date_genreate.flow[id][2]*1000 + (i+1)*(int(date_genreate.flow[id][3]/1000)+6):
                    if time_table[r][k][0] == flow_time[id] +j*date_genreate.flow[id][2]*1000 + (i+1)*(int(date_genreate.flow[id][3]/1000)+6):
                        if k == 0:
                            time_table[r][k][0] = time_table[r][k][0]-((i+1)*int(date_genreate.flow[id][3]/1000)+6)
                            break
                        else:
                            if time_table[r][k-1][1] == flow_time[id] +j*date_genreate.flow[id][2]*1000 + (i)*(int(date_genreate.flow[id][3]/1000)+6):
                                time_table[r][k][0] = time_table[r][k-1][0]
                                del time_table[r][k-1]
                                break
                            else:
                                time_table[r][k][0] = time_table[r][k][0] - (
                                            (i + 1) * int(date_genreate.flow[id][3] / 1000) + 6)
                                break
                    else:
                        if time_table[r][k-1][1] == flow_time[id] +j*date_genreate.flow[id][2]*1000 + (i)*(int(date_genreate.flow[id][3]/1000)+6):
                            time_table[r][k-1][1] = time_table[r][k-1][1] + int(date_genreate.flow[id][3]/1000)+6
                            break
                        else:
                            time_table[r].insert(k,[flow_time[id] +j*date_genreate.flow[id][2]*1000 + (i)*(int(date_genreate.flow[id][3]/1000)+6),flow_time[id] +j*date_genreate.flow[id][2]*1000 + (i+1)*(int(date_genreate.flow[id][3]/1000)+6)])
                            break



disable = []
flow_id = []
version = 1
for i in range(len(rout)):

    for j in range(len(date_genreate.path[i][rout[i]])-1):
        if version == 1:
            r = road_number(date_genreate.path[i][rout[i]][j],date_genreate.path[i][rout[i]][j+1])
        else:
            r = road_number2(date_genreate.path[i][rout[i]][j], date_genreate.path[i][rout[i]][j + 1])
        if r in disable:
            flow_id.append(date_genreate.flow[i])
            re_time(i,time_table)
            print(date_genreate.path[i][rout[i]])
            break

start = time.time()
schedule_result = []
flow_id.sort(key=lambda x: (x[2],x[3]))
for i in range(len(flow_id)):
    flow = flow_id[len(flow_id)-1-i]
    src = flow[0]-1
    dst = flow[1]-1
    timess = flow[2]
    lengths = flow[3]
    p = date_genreate.find_path(src,dst,date_genreate.paths)
    best_path = p[0]
    TS.caculate_load(path_loads,p[0],lengths/timess)
    v = np.std(path_loads) + 1500*len(p[0])
    for j in range(len(p)):
        temp_p = np.array(path_loads)
        TS.caculate_load(temp_p,p[j],lengths/timess/1000000)
        temp_v = np.std(temp_p) + 150*len(p[j])
        if temp_v < v:
            best_path = p[j]
            v = temp_v
    TS.caculate_load(path_loads,best_path,lengths/timess)
    length = int(lengths/1000) + 6
    path_len = len(best_path)

    schedule_result.append(find_slot(time_table,length,path_len-1,timess,best_path))
end = time.time()
print(schedule_result)
print(end-start)







