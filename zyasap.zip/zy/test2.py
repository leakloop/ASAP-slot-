import numpy as np
import test1


def slot_minize(slot1, slot2, length):
    slot = []
    for i in range(len(slot1)):
        for j in range(len(slot2)):
            if (slot1[i][0]-slot2[j][1])*(slot1[i][1]-slot2[j][0]) <=0:
                if slot1[i][0] <= slot2[j][1] and slot1[i][0] >= slot2[j][0] and slot1[i][1] >= slot2[j][1]:
                    if slot2[j][1] - slot1[i][0] >= length:
                        slot.append([slot1[i][0], slot2[j][1]])
                elif slot1[i][0] <= slot2[j][0] and slot1[i][1] >= slot2[j][1]:
                    if slot2[j][1] - slot2[j][0] >= length:
                        slot.append(slot2[j])
                elif slot2[j][0] <= slot1[i][1] and slot2[j][0] >= slot1[i][0] and slot2[j][1] >= slot1[i][1]:
                    if slot1[i][1] - slot2[j][0] >= length:
                        slot.append([slot2[j][0], slot1[i][1]])
                elif slot2[j][0] <= slot1[i][0] and slot2[j][1] >= slot1[i][1]:
                    if slot1[i][1] - slot1[i][0] >= length:
                        slot.append(slot1[i])
    return slot

def road_number(node_before, node_after):
    return test1.edges.index((node_before,node_after))
def div_slot(time_slot,x1,x2):
    time = []
    if x1 == time_slot[0]:
        time.append([x2,time_slot[1]])
    elif x2 ==time_slot[1]:
        time.append([time_slot[0],x1])
    else:
        time.append([time_slot[0],x1])
        time.append([x2,time_slot[1]])
    return time
def find_slot(time_table,length , path_len , times, best_path):
    slot = [[[]for i in range(int(4/times))]for j in range(path_len-1)]
    for h in range(path_len-1):

        road = road_number(best_path[h],
                            best_path[h + 1])

        temp = time_table[road]
        for i in range(int(4 / times)):   # 4是所有流量周期的超周期， times是该流量的周期， 在该路径上遍历所有周期来寻找可分类时隙， 单位与时隙窗口中的单位不一样， i是周期数
            for j in range(len(time_table[road])):  # 遍历该路径中可分配的时隙窗口，时隙窗口分配后数量可能会增加， j时隙窗口中可分配的时隙编号
                if (temp[j][0] - 1000*(i+1)*times)*(temp[j][1] - 1000*i*(times)) <= 0: # 当可分配的时隙满足分配条件时。分配条件是时隙大于流量长度，因为时隙可能存在于不同周期内，所以要先将时隙映射到第一个周期中。 temp是映射后的时隙//判断条件是前一个周期的开始时间小于下一个周期的开始时间
                    if temp[j][1] - temp[j][0] >= length:  # 对映射后的时隙做判断，是否满足调度条件，即时隙长度大于流量长度， 这一步后获得每个周期中映射后的可分配时隙，记为slot。slot有三个维度，第一个维度是路径，第二个维度是周期，第三个维度是可分配时隙[a ,b]
                        slot[h][i].append([max(temp[j][0] - h * length, 1000 * i * times - h * length)-1000*i*times, min(
                               [temp[j][1] - (h+1) * length,
                               (i + 1) * times * 1000 - (h+1) * length])-1000*i*times])
    slot1 = [[]for i in range(path_len-1)] # 接下来对可分配时隙进行建剪裁，遍历路径、周期两个维度来进行剪裁
    for i in range(path_len-1):  # i路径
        j = 0
        f = 0
        while j != len(slot[i][0]):  # 判断是否有可分配时隙，没有就失败
            if f == 0:
                temp_t = np.array(slot[i][0][j])
            conflict = 0
            f = 0
            for k in range(int(4/times)-1):  # k周期
                s = 0
                for h in range(len(slot[i][k+1])):
                    if (slot[i][k+1][h][0] - temp_t [1])*(slot[i][k+1][h][1] - temp_t[0]) <= 0:  # 剪裁，简单来说就是找到映射后所有可分配时隙的公共区域
                        s = 1
                        if slot[i][k+1][h][0] > temp_t[0]:
                            temp_t[0] = slot[i][k + 1][h][0]
                        if slot[i][k+1][h][1] < temp_t[1]:
                            temp_tt = np.array([slot[i][k+1][h][1]+1,temp_t[1]])
                            f = 1
                            temp_t[1] =  slot[i][k+1][h][1]

                if s == 0:
                    break
                conflict += s
            if conflict == int(4/times)-1:
                slot1[i].append(temp_t)
                if f == 1:
                    temp_t=temp_tt
                    j -= 1
            j += 1
    slot2 = slot1[0]
    for i in range(len(slot1)):  #选择剪裁后最前面的时隙进行分配
        slot2 = slot_minize(slot2, slot1[i], length-5)
    if slot2 == []:
        return -1
    for i in range(path_len - 1):

        road = road_number(best_path[i],
                            best_path[i + 1])
        for j in range(int(4 / times)):
            x1 = slot2[0][0] + j * times * 1000 + i * length
            x2 = slot2[0][0] + length + j * times * 1000 + i * length - 5
            for k in range(len(time_table[road])):
                if time_table[road][k][0] <= x1 and time_table[road][k][1] >= x2:
                    time1 = div_slot(time_table[road][k], x1, x2)
                    break
            del time_table[road][k]
            for l in range(len(time1)):
                time_table[road].insert(k + l, time1[l])
    return slot2[0][0]