import networkx as nx
import pandas as pd
import numpy as np
import random as rd
import topo

def flow_generate(flow_number,host_number):          #用来生成流量
    f = np.array([8*rd.randrange(64,1512,1) for i in range(flow_number)])
    t = np.array([rd.randrange(1,4,1) for i in range(flow_number)])
    src = np.array([rd.randrange(1,host_number+1,1) for i in range(flow_number)])
    dst = np.array([rd.randrange(1,host_number+1,1) for i in range(flow_number)])
    np.transpose(f)
    t.reshape([-1,flow_number])
    src.reshape([-1,flow_number])
    dst.reshape([-1,flow_number])
    for i in range(flow_number):
        if src[i] == dst[i]:
            temp = rd.randrange(0, host_number-1, 1)
            hosts = []
            for j in range(host_number):
                if j+1 != src[i]:
                    hosts.append(j+1)
            dst[i] = hosts[temp]
        if t[i] == 3:
            t[i] = 4
    np.multiply(t,1000)
    flow = np.array([[0 for i in range(4)]for j in range(flow_number)])
    flow[:,0]=src #源节点
    flow[:,1]=dst #目的节点
    flow[:,2]=t   #周期
    flow[:,3]=f   #长度
    return flow
flow_number = 1
# a2 = pd.read_excel('C:/Users/98743/Desktop/毕业设计/ILP/20flow.xlsx')
# a = pd.read_excel('result_xlsx.xlsx')
# flow = np.array([[0 for i in range(4)]for j in range(flow_number)])
# for i in range(flow_number):
#     flow[i][0] = np.array(a['源节点']).reshape(-1,1)[i]
#     flow[i][1] = np.array(a['目的节点']).reshape(-1,1)[i]
#     flow[i][2] = np.array(a['周期']).reshape(-1,1)[i]
#     flow[i][3] = np.array(a['长度']).reshape(-1,1)[i]


flow = flow_generate(flow_number,8)
columns = ["源节点","目的节点","周期","长度"]
dt = pd.DataFrame(flow,columns=columns)
dt.to_excel("result_xlsx.xlsx",index=0)
nodes = topo.nodes5
edges = topo.edges5
G=nx.Graph()
for node in nodes:
    G.add_node(node)
r=G.add_edges_from(edges)
As = nx.adjacency_matrix(G)
Snetwork = As.todense()
def find_path(src,dst):                        #寻找源节点和目的节点为特定值的路径
    S = nodes[src]
    D = nodes[dst]
    return list(nx.all_simple_paths(G,S,D))

path = []
pathlen = []
for i in range(len(flow)):
    p = find_path(flow[i][0]-1, flow[i][1]-1)
    pathlen.append(len(p))
    path.append(p)

short = [0]*len(flow)
k=0
for i in path:
    temp = len(i[0])
    for j in range(len(i)):
        if len(i[j]) < temp:
            short[k] = j
    k += 1

