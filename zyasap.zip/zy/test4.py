import test2
import test1
import numpy as np
import time
import pandas as pd
import matplotlib.pyplot as plt
import plotly.figure_factory as ff

def caculate_load(path_load, path, load):
    for i in range(len(path)-1):
        road_number = test1.edges.index((path[i],path[i+1]))
        path_load[road_number] += load

if __name__ == '__main__':
    time_table = [[] for i in range(len(test1.edges))]
    for i in range(len(test1.edges)):
        time_table[i].append([0, 4000])
    path_load = [0] * (len(test1.edges))
    flow = []
    flow_number = test1.flow_number
    time_start = time.time()
    for i in range(flow_number):
        flow.append(test1.flow[i])
        flow[i][3] = -flow[i][3]
    flow.sort(key=lambda x: (x[2], x[3]))
    schedule = [[] for i in range(flow_number)]
    weight = 500
    times_sch = []
    max_time = 0
    min_time = 100
    for i in range(flow_number):
        time_s = time.time()
        src = flow[i][0] - 1
        dst = flow[i][1] - 1
        times = flow[i][2]
        length = -flow[i][3]
        p = test1.find_path(src, dst)
        ttt = time.time() - time_s
        p_v = [0] * len(p)
        length_take = int(length / 1000) + 6
        sch = 0
        for j in range(len(p)):
            temp_p = np.array(path_load)
            caculate_load(temp_p, p[j], length / times)
            p_v[j] = 0 * np.std(temp_p) + weight * len(p[j])
        b = sorted(zip(p_v, range(len(p_v))))
        tttt = time.time() - time_s
        b.sort(key=lambda x: x[0])
        c = [x[1] for x in b]
        for j in range(len(p)):
            sch += 1
            path = p[c[j]]    #链路负载最小的链路作为路径
            temp_table = time_table
            temp_schedule = test2.find_slot(time_table, length_take, len(path), times, path)
            if temp_schedule != -1:
                caculate_load(path_load, p[c[j]], length / times)
                break
        schedule[i] = temp_schedule
        ttttt = time.time() - time_s
        time_e = time.time()
        flow_time = time_e - time_s
        if flow_time > max_time:
            max_time = flow_time
        if flow_time < min_time:
            min_time = flow_time
        times_sch.append(sch)
    time_end = time.time()
    t = time_end - time_start
    print("time:" + str(t))
    success = 0



    for i in range(flow_number):
        if schedule[i] != -1:
            success += 1
    print("success_rate:" + str(success / flow_number))
    print("average time of flow" + str(sum(times_sch) / test1.flow_number))
    print("minimum time of flow" + str(min_time))
    print("maximum time of flow" + str(max_time))
