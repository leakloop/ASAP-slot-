#conflict 原来是通过禁忌搜索方法对流量进行调度的文件，后来主要用到了其中的函数div_slot()用来分割连续的时间资源。

import numpy as np
import random as rd
import time
import TS
from time_schedule3 import road_number
import matplotlib.pyplot as plt
import date_genreate
import itertools


def insert(x,a,b):
    temp = x[b]
    x[b:-1] = x[b+1:]
    x[a+1:] = x[a:-1]
    x[a] = temp
def swap(x,a,b):
    temp = x[b]
    x[b] = x[a]
    x[a] = temp



def div_slot(time_slot,x1,x2):
    time = []
    if x1 == time_slot[0]:
        time.append([x2,time_slot[1]])
    elif x2 ==time_slot[1]:
        time.append([time_slot[0],x1])
    else:
        time.append([time_slot[0],x1])
        time.append([x2,time_slot[1]])
    return time



class time_schedule3():
    def __init__(self, vcount = 20, ccount = 10, tabul = 25, iters = 200, tabu_objects=10, times = [], path_len = [],length = [], rout_solu = []):
        self.vcount = vcount
        self.ccount = ccount
        self.iters = iters
        self.tabu_len = tabul
        self.tabu_objs = tabu_objects
        self.tabu_list = [None] * self.tabu_objs
        self.tabu_len_list = np.array([0] * self.tabu_objs)
        self.cur_solu = np.array([0]*self.vcount)
        self.best_solu = np.array([0]*self.vcount)
        self.trace = []
        self.times = times
        self.path_len = path_len
        self.length = length
        self.rout_solu = rout_solu
        self.road_flow = np.array([[-1 for i in range(self.vcount)]for j in range(22)])
        self.road_len = np.array([0]*22)



    def shape(self, x, flow_rank):
        for i in range(22):
            p = 0
            for j in range(self.vcount):
                for k in range(self.road_len[i]):
                    if self.road_flow[i][k] == x[j]:
                        flow_rank[i][p] = self.road_flow[i][k]
                        p += 1

    def valuate2(self,x,time_table =[]):
        flow_rank = np.array([[-1 for i in range(self.vcount)] for j in range(22)])
        self.shape(x, flow_rank)

        flow_time = [0] * self.vcount
        if time_table == [] :
            time_table = [[] for i in range(22)]
            for i in range(22):
                time_table[i].append([0,4000])
        for i in range(self.vcount):
            self.find_slot(x[i],time_table,flow_time)
        return flow_time


    def find_slot(self,x,time_table,flow_time):
        if x == 15:
            x=15
        elif x == 18:
            x = 18
        slot = [[[]for i in range(int(4/self.times[x]))]for j in range(self.path_len[x])]
        for h in range(self.path_len[x]):

            road = road_number(date_genreate.path[x][self.rout_solu[x]][h],
                                date_genreate.path[x][self.rout_solu[x]][h + 1])
            temp=time_table[road]
            for i in range(int(4 / self.times[x])):
                for j in range(len(time_table[road])):
                    if (temp[j][0] - 1000*(i+1)*self.times[x])*(temp[j][1] - 1000*i*(self.times[x])) <= 0:
                        if temp[j][1] - temp[j][0] >= self.length[x]:
                            slot[h][i].append([max(temp[j][0] - h * self.length[x], 1000 * i * self.times[x] - h * self.length[x])-1000*i*self.times[x], min(
                                [temp[j][1] - (h+1) * self.length[x],
                                 (i + 1) * self.times[x] * 1000 - (h+1) * self.length[x]])-1000*i*self.times[x]])
        slot1 = [[]for i in range(self.path_len[x])]
        for i in range(self.path_len[x]):
            j = 0
            f1 = 0
            while j != len(slot[i][0]):
                if f1 == 0:
                    temp_t = np.array(slot[i][0][j])
                conflict = 0
                f1 = 0
                for k in range(int(4/self.times[x])-1):
                    s = 0
                    for h in range(len(slot[i][k+1])):
                        if (slot[i][k+1][h][0] - temp_t [1])*(slot[i][k+1][h][1] - temp_t[0]) <= 0:
                            s = 1
                            if slot[i][k+1][h][0] > temp_t[0]:
                                temp_t[0] = slot[i][k + 1][h][0]
                            if slot[i][k+1][h][1] < temp_t[1]:
                                f1 = 1
                                t_t = [slot[i][k+1][h][1]+1,temp_t[1]]
                                temp_t[1] =  slot[i][k+1][h][1]
                    if s == 0:
                        break
                    conflict += s
                if conflict == int(4/self.times[x])-1:
                    slot1[i].append(temp_t)
                if f1 == 1:
                    temp_t = t_t
                j+=1
        slot2 = []

        for i in range(len(slot1[0])):
            if self.path_len[x] == 3:


                for j in range(len(slot1[1])):
                    conflict = 0
                    temp_tt = np.array(slot1[0][i])
                    if (slot1[1][j][1] - temp_tt[0])*(slot1[1][j][0] - temp_tt[1]) <= 0:
                        if slot1[1][j][0] > temp_tt[0]:
                            temp_tt[0] = slot1[1][j][0]
                        if slot1[1][j][1] < temp_tt[1]:
                            temp_tt[1] = slot1[1][j][1]
                        conflict += 1
                        for k in range(len(slot1[2])):
                            if (slot1[2][k][1] - temp_tt[0]) * (slot1[2][k][0] - temp_tt[1]) <= 0:
                                if slot1[2][k][0] > temp_tt[0]:
                                    temp_tt[0] = slot1[2][k][0]
                                if slot1[2][k][1] < temp_tt[1]:
                                    temp_tt[1] = slot1[2][k][1]
                                conflict += 1
                            if conflict == self.path_len[x]-1:
                                break
                        if conflict == self.path_len[x]-1:
                            slot2.append(temp_tt)
                            break
            elif self.path_len[x] == 2:
                temp_tt = np.array(slot1[0][i])

                for j in range(len(slot1[1])):
                    conflict = 0
                    if (slot1[1][j][1] - temp_tt[0])*(slot1[1][j][0] - temp_tt[1]) <= 0:
                        if slot1[1][j][0] > temp_tt[0]:
                            temp_tt[0] = slot1[1][j][0]
                        if slot1[1][j][1] < temp_tt[1]:
                            temp_tt[1] = slot1[1][j][1]
                        conflict += 1
                        if conflict == self.path_len[x]-1:
                            slot2.append(temp_tt)
                            break
            elif self.path_len[x] == 4:
                temp_tt = np.array(slot1[0][i])

                for j in range(len(slot1[1])):
                    conflict = 0
                    if (slot1[1][j][1] - temp_tt[0])*(slot1[1][j][0] - temp_tt[1]) <= 0:
                        if slot1[1][j][0] > temp_tt[0]:
                            temp_tt[0] = slot1[1][j][0]
                        if slot1[1][j][1] < temp_tt[1]:
                            temp_tt[1] = slot1[1][j][1]
                        conflict += 1
                        for k in range(len(slot1[2])):
                            if (slot1[2][k][1] - temp_tt[0]) * (slot1[2][k][0] - temp_tt[1]) <= 0:
                                if slot1[2][k][0] > temp_tt[0]:
                                    temp_tt[0] = slot1[2][k][0]
                                if slot1[2][k][1] < temp_tt[1]:
                                    temp_tt[1] = slot1[2][k][1]
                                conflict += 1
                                for h in range(len(slot1[3])):
                                    if (slot1[3][h][1] - temp_tt[0]) * (slot1[3][h][0] - temp_tt[1]) <= 0:
                                        if slot1[3][h][0] > temp_tt[0]:
                                            temp_tt[0] = slot1[3][h][0]
                                        if slot1[3][h][1] < temp_tt[1]:
                                            temp_tt[1] = slot1[3][h][1]
                                        conflict += 1
                                    if conflict == self.path_len[x] - 1:
                                        break
                            if conflict == self.path_len[x]-1:
                                break
                        if conflict == self.path_len[x]-1:
                            slot2.append(temp_tt)
                            break



        # for i in range(len(slot1[0])):
        #     temp_tt = np.array(slot1[0][i])
        #     conflict = 0
        #     for j in range(self.path_len[x]-1):
        #         s = 0
        #         for k in range(len(slot1[j+1])):
        #             if (slot1[j+1][k][1] - temp_tt[0])*(slot1[j+1][k][0] - temp_tt[1]) <= 0:
        #                 s = 1
        #                 if slot1[j + 1][k][0] > temp_tt[0]:
        #                     temp_tt[0] = slot1[j + 1][k][0]
        #                 if slot1[j + 1][k][1] < temp_tt[1]:
        #                     temp_tt[1] = slot1[j + 1][k][1]
        #         if s == 0:
        #             break
        #         conflict += s
        #     if conflict == self.path_len[x]-1:
        #         slot2.append(temp_tt)
        #         break
        for i in range(self.path_len[x]):
            road = road_number(date_genreate.path[x][self.rout_solu[x]][i],
                                date_genreate.path[x][self.rout_solu[x]][i + 1])
            for j in range(int(4 / self.times[x])):
                x1 = slot2[0][0] + j * self.times[x] * 1000 + i * self.length[x]
                x2 = slot2[0][0] + self.length[x] + j * self.times[x] * 1000 + i * self.length[x]
                for k in range(len(time_table[road])):
                    if time_table[road][k][0] <= x1 and time_table[road][k][1] >= x2:
                        time = div_slot(time_table[road][k], x1, x2)
                        break
                del time_table[road][k]
                for l in range(len(time)):
                    time_table[road].insert(k + l, time[l])
        flow_time[x] = slot2[0][0]



    def permutation(self):
        for i in range(self.vcount):
            for j in range(self.path_len[i]):
                a = road_number(date_genreate.path[i][self.rout_solu[i]][j],
                                date_genreate.path[i][self.rout_solu[i]][j + 1])
                b = np.array(np.where(self.road_flow[a] == -1))
                self.road_flow[a][b[0][0]] = i
                self.road_len[a] = self.road_len[a] + 1

    def update_Tabu(self,mode, index=None, solu=None):
        indices = []
        for i in range(len(self.tabu_len_list)):
            if self.tabu_len_list[i] != 0:
                self.tabu_len_list[i] -= 1
        if mode == 'release':
            self.sequence_Tabu(index)
        elif mode == 'add':
            tabuObj = self.valuate2(solu)
            # tabuObj = self.valuate(solu)
            if self.tabu_list[0] == None:
                self.sequence_Tabu(0)
            self.tabu_list[len(self.tabu_list) - 1] = tabuObj
            self.tabu_len_list[len(self.tabu_list) - 1] = self.tabu_len
        for i in range(len(self.tabu_len_list)):
            if self.tabu_len_list[i] == 0:
                indices.append(i)
        if len(indices) == 1:
            self.sequence_Tabu(indices[0])
        elif len(indices) > 1:
            maxindex = max(indices)
            self.sequence_Tabu(maxindex)
            for i in indices:
                if i != max(indices):
                    self.tabu_list[i] = None
                    self.tabu_len_list[i] = 0
            objs = []
            objs1 = []
            for obj in self.tabu_list[:maxindex]:
                if obj != None:
                    objs.append(obj)
            for obj in self.tabu_len_list[:maxindex]:
                if obj != 0:
                    objs1.append(obj)
            if objs != []:
                for i in range(len(objs)):
                    self.tabu_list[maxindex - i - 1] = objs[i]
                    self.tabu_len_list[maxindex - i - 1] = objs1[i]
                for i in range(maxindex - len(objs)):
                    self.tabu_list[i] = None
                    self.tabu_len_list[i] = 0
            else:
                for i in range(maxindex):
                    self.tabu_list[i] = None
                    self.tabu_len_list[i] = 0

    def sequence_Tabu(self, index):
        if index != len(self.tabu_list) - 1:
            for i in range(len(self.tabu_list) - 1 - index):
                self.tabu_list[index + i] = self.tabu_list[index + i + 1]
                self.tabu_len_list[index + i] = self.tabu_len_list[index + i + 1]
            self.tabu_list[len(self.tabu_list) - 1] = None
            self.tabu_len_list[len(self.tabu_len_list) - 1] = 0

    def run(self):

        flow = []
        step1 = 1
        if step1 < 1 :
            step1 = 1
        step2 = 1
        if step2 < 1 :
            step2 = 1
        step3 = 1
        if step3 < 1 :
            step3 = 1
        step4 = 1

        length = sorted(enumerate(np.multiply(self.length,self.path_len)), key=lambda x: x[1])
        idl = [i[0] for i in length]
        for i in range(3):
            for j in range(int(self.vcount/3)+1):
                if j * 3 + i > self.vcount - 1:
                    continue
                flow.append(idl[j * 3 + i])
        # flow = [16,9,4,3,13,10,2,17,5,6,12,19,8,15,18,1,7,11,0,14]
        self.cur_solu = flow
        self.best_solu = flow
        self.update_Tabu('add', solu=self.cur_solu)


        last_b = np.array([0]*self.vcount)
        counter = 0
        while counter < self.iters:
            att=0
            if len(self.trace)>0:
                if self.valuate2(self.best_solu) != self.trace[-1]:
                    error = 1
            counter += 1
            candi_solu = np.array([[0 for i in range(self.vcount)]for j in range(self.ccount)])
            step = 1
            if counter < 40:
                step=step1
            else:
                step = step4
            for i in range(self.ccount):
                temp1 = self.cur_solu
                if step == 1:
                    a = rd.randint(0, self.vcount - 1)
                    b = rd.randint(0, self.vcount - 1)
                    if i < 5:
                        candi_solu[i][b] = temp1[a]
                        k = 0
                        for j in range(self.vcount):
                            if j != b:
                                if k == a:
                                    k += 1
                                candi_solu[i][j] = temp1[k]
                                k += 1

                    else:
                        candi_solu[i] = temp1
                        candi_solu[i][a] = temp1[b]
                        candi_solu[i][b] = temp1[a]
                else:
                    if step == step1:
                        a = rd.randint(0, int(self.vcount/4)-1)
                        b = rd.randint(0, int(self.vcount/4)-1)
                        if i < 5:
                            for j in range(step1):
                                insert(temp1,a*step1+j,b*step1+j)
                            candi_solu[i] = temp1
                        else:
                            for j in range(step1):
                                swap(temp1,a*step1+j,b*step1+j)
                            candi_solu[i] = temp1
                    elif step == step2:
                        a = rd.randint(0, int(self.vcount/3)-1)
                        b = rd.randint(0, int(self.vcount/3)-1)
                        if i < 5:
                            for j in range(step2):
                                insert(temp1,a*step2+j,b*step2+j)
                            candi_solu[i] = temp1
                        else:
                            for j in range(step2):
                                swap(temp1,a*step2+j,b*step2+j)
                            candi_solu[i] = temp1
                    elif step == step3:
                        a = rd.randint(0, int(self.vcount/2)-1)
                        b = rd.randint(0, int(self.vcount/2)-1)
                        if i < 5:
                            for j in range(step3):
                                insert(temp1,a*step3+j,b*step3+j)
                            candi_solu[i] = temp1
                        else:
                            for j in range(step3):
                                swap(temp1,a*step3+j,b*step3+j)
                            candi_solu[i] = temp1
            isALL = False
            isPart = False
            count = [0] * self.ccount
            for i in range(self.ccount):
                v_can = self.valuate2(candi_solu[i])
                for k in range(len(self.tabu_list)):
                    if v_can == self.tabu_list[k]:
                        count[i] = 1
            temp = 0
            for i in count:
                if i == 1:
                    temp += 1
            if temp == self.ccount:
                isALL = True
            elif temp < self.ccount and temp > 0:
                isPart = True

            if isALL == True:
                att += 1
                temp_tabu_list = []
                for tabuObj in self.tabu_list:
                    if tabuObj != None:
                        temp_tabu_list.append(tabuObj)
                index = np.argmin(np.array(temp_tabu_list))
                temp_solu = np.array([0] * self.vcount)
                for solu in candi_solu:
                    if self.valuate2(solu) == self.tabu_list[index]:
                        temp_solu = solu
                self.cur_solu = temp_solu
                if self.valuate2(self.cur_solu) < self.valuate2(self.best_solu):
                    self.best_solu = self.cur_solu

                self.update_Tabu('release', index=index)
            elif isPart == True:
                att += 1
                isExistbest = False
                temp_bsolu = []
                bsolu = np.array([0] * self.vcount)
                for solu in candi_solu:
                    if self.valuate2(solu) < self.valuate2(self.best_solu):
                        isExistbest = True
                        temp_bsolu.append(solu)
                if isExistbest == True:
                    isInTabu = False
                    index = 0
                    if len(temp_bsolu) == 1:
                        bsolu = temp_bsolu[0]
                        v_can = self.valuate2(bsolu)
                    elif len(temp_bsolu) != 1 and len(temp_bsolu) != 0:
                        bsolu = temp_bsolu[0]
                        v_can = self.valuate2(bsolu)
                        for solu in temp_bsolu[1:]:
                            if self.valuate2(solu) < v_can:
                                bsolu = solu
                                v_can = self.valuate2(bsolu)
                    for i in range(len(self.tabu_list)):
                        if self.valuate2(bsolu) == self.tabu_list[i]:
                            isInTabu = True
                            index = i
                    self.cur_solu = bsolu
                    if self.valuate2(bsolu) < self.valuate2(self.best_solu):
                        self.best_solu = bsolu

                    if isInTabu == True:
                        self.update_Tabu('release', index=index)
                    else:
                        index = len(self.tabu_list) - 1
                        self.update_Tabu(index, 'add', solu=self.cur_solu)
                else:
                    notInTabu = []
                    for solu in candi_solu:
                        v_can = self.valuate2(solu)
                        count = 0
                        for i in range(len(self.tabu_list)):
                            if v_can != self.tabu_list[i]:
                                count += 1
                        if count == len(self.tabu_list):
                            notInTabu.append(solu)
                    temp_solu = notInTabu[0]
                    if len(notInTabu) != 1:
                        for solu in notInTabu[1:]:
                            if self.valuate2(solu) < self.valuate2(temp_solu):
                                temp_solu = solu
                    if self.valuate2(temp_solu) < self.valuate2(self.cur_solu):
                        self.cur_solu = temp_solu
                        self.update_Tabu('add', index=len(self.tabu_list) - 1, solu=self.cur_solu)
                        if self.valuate2(self.cur_solu) < self.valuate2(self.best_solu):
                            self.best_solu = self.cur_solu
                            att+=1
            else:
                bcandi_solu = candi_solu[0]
                v_bcandi = self.valuate2(bcandi_solu)
                for solu in candi_solu[1:]:
                    if self.valuate2(solu) < v_bcandi:
                        bcandi_solu = solu
                        v_bcandi = self.valuate2(bcandi_solu)
                if self.valuate2(bcandi_solu) < self.valuate2(self.cur_solu):
                    self.cur_solu = bcandi_solu
                    self.update_Tabu('add', index=len(self.tabu_list) - 1, solu=self.cur_solu)
                    if len(self.trace) > 0:
                        if self.valuate2(self.best_solu) != self.trace[-1]:
                            if (np.array(self.best_solu)== last_b).all():
                                error = 1
                            error = 2
                    if self.valuate2(self.cur_solu) < self.valuate2(self.best_solu):
                        self.best_solu = self.cur_solu
            last_b = np.array(self.best_solu)
            self.trace.append(self.valuate2(self.best_solu))

def main():
    start1 = time.time()
    times = []
    length = []
    path_len = []
    ts = TS.TS(iters=300,vcount=20)
    ts.run()
    for i in range(ts.vcount):
        times.append(date_genreate.flow[i][2])
        length.append(int(date_genreate.flow[i][3]/1000) + 6)
        path_len.append(len(date_genreate.path[i][ts.best_solu[i]]) - 1)
    time_s = time_schedule3(iters=400,times=times,length=length,path_len=path_len,rout_solu=ts.best_solu,vcount=20,tabul=10,tabu_objects=25,ccount=15)

    time_s.permutation()
    time_s.run()
    end1 = time.time()
    print(end1 - start1)
    print('最优解:', time_s.best_solu)
    print('最小值', time_s.valuate2(time_s.best_solu))

    plt.subplot(2,1,1)
    plt.plot(time_s.trace, 'r')
    TS.show_path(ts.best_solu)
    title = 'TS: ' + str(time_s.valuate2(time_s.best_solu))
    plt.title(title)
    rank = []
    for i in range(time_s.vcount):
        rank.append(time_s.length[time_s.best_solu[i]]*time_s.path_len[time_s.best_solu[i]])
    rank = np.array(rank)
    plt.subplot(2,1,2)
    plt.plot(rank)
    #     plt.scatter(i,time_s.length[time_s.best_solu[i]],c='blue')
    plt.show()

if __name__ == "__main__":

    main()