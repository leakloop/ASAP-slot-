import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
from pylab import *
mpl.rcParams['font.sans-serif'] = ['SimHei']
import time
# t_mean = [0.005797,0.015715,0.031217,0.043921]
# t_min = [0.000964,0.000993,0.000997,0.000983]
# t_max = [0.01895,0.215041,0.432286,0.43619]
# x = [500,1000,1500,2000]
# times = [1,1.557,3.414,3.914]
# title = "excution time of 2000flow"
# plt.title(title)
# plt.plot(x,times,'b*--', alpha=0.5, linewidth=1)
# plt.xlabel('number of flow')
# plt.ylabel('Average scheduling times')
# plt.show()

# title = "excution time of 2000flow"
# plt.title(title)
# plt.plot(x,t_mean,'b*--', alpha=0.5, linewidth=1, label='Average excution time')
# plt.plot(x,t_min,'rs--', alpha=0.5, linewidth=1, label='Minimun excution time')
# plt.plot(x,t_max,'go--', alpha=0.5, linewidth=1, label='Maximun excution time')
# plt.legend()
# plt.xlabel('number of flow')
# plt.ylabel('time flow/second')
# plt.show()

t_300=[0.002004,0.002204,0.002836,0.003753,0.007224,0.011705]
t_600=[0.003552,0.003733,0.004769,0.006672,0.009707,0.015199]
t_900=[0.005952,0.006516,0.007709,0.010769,0.015834,0.020831]
t_1200=[0.007844,0.012621,0.016206,0.043517,0.070117,0.082499]
x_topo=[3,6,9,12,15,18]
plt.plot(x_topo,t_300,'b*-', alpha=0.5, linewidth=1.5, label='300条流')
plt.plot(x_topo,t_600,'rs-', alpha=0.5, linewidth=1.5, label='600条流')
plt.plot(x_topo,t_900,'go-', alpha=0.5, linewidth=1.5, label='900条流')
plt.plot(x_topo,t_1200,'mD-', alpha=0.5, linewidth=1.5, label='1200条流')
plt.legend()
plt.xlabel('交换机之间的链路数量')
plt.ylabel('时间   (s/flow)')
plt.show()

#
# def to_percent(temp,position):
#     return '%1.0f'%(temp)+'%'
#
# success_rate = [[100,100],[100,100],[100,100],[87,85]]
# y11 = [i[0] for i in success_rate]
# y22 = [i[1] for i in success_rate]
#
# times_flow=[[1,1],[1,1],[1,2.4611],[8.23667,10.72583]]
# x=['300','600','900','1200']
# plt.xlabel("流的数量")
# plt.ylabel("平均的调度次数")
# # plt.title("最短路径法及本文路由算法下对调度的影响")
# x1 = [1,5,9,13]
# x2 = [i+1 for i in x1]
# x3 = [i+0.5 for i in x1]
# y1 = [i[0] for i in times_flow]
# y2 = [i[1] for i in times_flow]
# y0=["","","",""]
# plt.bar(x1,y2,alpha=0.7,width=1,label="最短路径算法",tick_label=y0)
# plt.bar(x2,y1,alpha=0.7,width=1,label="本文路由算法",tick_label=y0)
# plt.legend(bbox_to_anchor=(0,0.8),loc="center left")
# plt.xticks(x3,x)
# plt.twinx()
# plt.plot(x3,y22,'s-', alpha=0.5, linewidth=1.5, label='最短路径算法')
# plt.plot(x3,y11,'*-', alpha=0.5, linewidth=1.5, label='本文路由算法')
# plt.gca().yaxis.set_major_formatter(FuncFormatter(to_percent))
# plt.show()


# times_flow=[[0.0163,0.0010],[0.0200,0.0010],[0.0210,0.0010],[0.0251,0.0010]]
# x=['10+1','20+1','30+1','40+1']
# plt.xlabel("流的数量")
# plt.ylabel("算法运行时间 (s)")
# # plt.title("新增一条流量")
# x1 = [1,5,9,13]
# x2 = [i+1 for i in x1]
# x3 = [i+0.5 for i in x1]
# y1 = [i[0] for i in times_flow]
# y2 = [i[1] for i in times_flow]
# y0=["","","",""]
# plt.bar(x1,y1,alpha=0.7,width=1,label="基于ILP的动态流量均衡调度算法",tick_label=y0)
# plt.bar(x2,y2,alpha=0.7,width=1,label="动态增量路由与调度联合优化算法",tick_label=y0)
# plt.xticks(x3,x)
# plt.legend()
# plt.show()


# times_flow=[[0.0130,0.0010],[0.0131,0.0029],[0.1710,0.0090],[0.3330,0.0179]]
# x=['10','20','30','40']
# plt.xlabel("流的数量")
# plt.ylabel("算法运行时间 (s)")
# # plt.title("一条链路故障")
# x1 = [1,5,9,13]
# x2 = [i+1 for i in x1]
# x3 = [i+0.5 for i in x1]
# y1 = [i[0] for i in times_flow]
# y2 = [i[1] for i in times_flow]
# y0=["","","",""]
# plt.bar(x1,y1,alpha=0.7,width=1,label="基于ILP的动态流量均衡调度算法",tick_label=y0)
# plt.bar(x2,y2,alpha=0.7,width=1,label="动态增量路由与调度联合优化算法",tick_label=y0)
# plt.xticks(x3,x)
# plt.legend()
# plt.show()

# t_mean = [0.002004,0.003552,0.005952,0.007844]
# t_min = [0,0,0,0]
# t_max = [0.011091,0.020036,0.029986,0.049867]
# x = [300,600,900,1200]
# plt.plot(x,t_mean,'b*-', alpha=0.5, linewidth=1.5, label='平均执行时间')
# plt.plot(x,t_min,'rs-', alpha=0.5, linewidth=1.5, label='最小执行时间')
# plt.plot(x,t_max,'go-', alpha=0.5, linewidth=1.5, label='最大执行时间')
# plt.legend()
# plt.xlabel('流的数量')
# plt.ylabel('执行时间 (s/flow)')
# plt.show()