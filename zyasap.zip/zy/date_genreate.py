#用来生成流量、初始化网络资源、设置网络拓扑、寻找所有路径

# import xlrd
import random as rd
import numpy as np
import pandas as pd

def flow_generate(flow_number):          #用来生成流量
    f = np.array([8*rd.randrange(64,1512,1) for i in range(flow_number)])
    t = np.array([rd.randrange(1,4,1) for i in range(flow_number)])
    src = np.array([rd.randrange(1,9,1) for i in range(flow_number)])
    dst = np.array([rd.randrange(1,9,1) for i in range(flow_number)])
    np.transpose(f)
    t.reshape([-1,flow_number])
    src.reshape([-1,flow_number])
    dst.reshape([-1,flow_number])
    for i in range(flow_number):
        if src[i] == dst[i]:
            temp = rd.randrange(0, 7, 1)
            hosts = []
            for j in range(8):
                if j+1 != src[i]:
                    hosts.append(j+1)
            dst[i] = hosts[temp]
        if t[i] == 3:
            t[i] = 4
    np.multiply(t,1000)
    flow = np.array([[0 for i in range(4)]for j in range(flow_number)])
    flow[:,0]=src
    flow[:,1]=dst
    flow[:,2]=t
    flow[:,3]=f
    return flow
flow_number = 40
# # a2 = pd.read_excel('C:/Users/98743/Desktop/毕业设计/ILP/20flow.xlsx')
# a = pd.read_excel('result_xlsx.xlsx')
# flow = np.array([[0 for i in range(4)]for j in range(flow_number)])
# for i in range(flow_number):
#     flow[i][0] = np.array(a['源节点']).reshape(-1,1)[i]
#     flow[i][1] = np.array(a['目的节点']).reshape(-1,1)[i]
#     flow[i][2] = np.array(a['周期']).reshape(-1,1)[i]
#     flow[i][3] = np.array(a['长度']).reshape(-1,1)[i]


flow = flow_generate(flow_number)
columns = ["源节点","目的节点","周期","长度"]
dt = pd.DataFrame(flow,columns=columns)
dt.to_excel("result_xlsx.xlsx",index=0)

network = [[0,0,0,0,0,0,0,0,1,0,0],             #网络拓扑邻接矩阵
           [0,0,0,0,0,0,0,0,1,0,0],
           [0,0,0,0,0,0,0,0,1,0,0],
           [0,0,0,0,0,0,0,0,0,1,0],
           [0,0,0,0,0,0,0,0,0,1,0],
           [0,0,0,0,0,0,0,0,0,1,0],
           [0,0,0,0,0,0,0,0,0,0,1],
           [0,0,0,0,0,0,0,0,0,0,1],
           [1,1,1,0,0,0,0,0,0,1,1],
           [0,0,0,1,1,1,0,0,1,0,1],
           [0,0,0,0,0,0,1,1,1,1,0]]

network2 = [[0,0,0,0,0,0,0,0,1,0,0,0],
            [0,0,0,0,0,0,0,0,1,0,0,0],
            [0,0,0,0,0,0,0,0,0,1,0,0],
            [0,0,0,0,0,0,0,0,0,1,0,0],
            [0,0,0,0,0,0,0,0,0,0,1,0],
            [0,0,0,0,0,0,0,0,0,0,1,0],
            [0,0,0,0,0,0,0,0,0,0,0,1],
            [0,0,0,0,0,0,0,0,0,0,0,1],
            [1,1,0,0,0,0,0,0,0,1,1,1],
            [0,0,1,1,0,0,0,0,1,0,1,1],
            [0,0,0,0,1,1,0,0,1,1,0,1],
            [0,0,0,0,0,0,1,1,1,1,1,0]]

def iter_paths(adj, min_length=2, path=None):                  #寻找所有路径
    if not path:
        for start_node in range(len(adj)):
            yield from iter_paths(adj, min_length, [start_node])
    else:
        # yield a path as soon as we first encounter it
        if len(path) >= min_length:
            yield path
        # if we encounter a cycle (current location has been visited before)
        # then don't continue to recur
        if path[-1] in path[:-1]:
            return
        # search for all paths forward from the current node, recursively
        current_node = path[-1]
        for next_node in range(len(adj[current_node])):
            if adj[current_node][next_node] == 1:
                yield from iter_paths(adj, min_length, path + [next_node])
paths = list(iter_paths(network))
paths2 = list(iter_paths(network2))

def find_path(src,dst,paths):                        #寻找源节点和目的节点为特定值的路径
    path = []
    for i in paths:
        a = i[0]
        b = i[-1]
        if i[0] == src :
            if i[-1] == dst:
                path.append(i)
    return path

path = []
pathlen = []
for i in range(len(flow)):
    p = find_path(flow[i][0]-1, flow[i][1]-1, paths)
    pathlen.append(len(p))
    path.append(p)

short = [0]*len(flow)
k=0
for i in path:
    temp = len(i[0])
    for j in range(len(i)):
        if len(i[j]) < temp:
            short[k] = j
    k += 1




